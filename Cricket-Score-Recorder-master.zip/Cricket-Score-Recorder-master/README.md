# Cricket-Score-Recorder
It's a Android application which records the data of any cricket match. 
For now, It is partially completed, some more modification are still remains to change.
